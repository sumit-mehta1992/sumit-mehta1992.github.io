---
layout: home
title: "Home"
---

This theme allows an academic person to showcase their research interests, publications, research group, curriculum vitae, any courses that they may be teaching, or anything else they may want to put out into the world.

Academics can use this home page to describe their research interests, display their latest publications, or provide an introduction to their research group.
