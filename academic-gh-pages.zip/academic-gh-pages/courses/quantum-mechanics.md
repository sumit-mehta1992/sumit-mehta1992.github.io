---
layout: page
title: "Quantum Mechanics"
---

#### Course Information

[Course Outline](/courses/quantum-mechanics/Sample_Course_Outline.pdf)

#### Lecture Notes

[Lecture 1](/courses/quantum-mechanics/Sample_Lecture_Notes.pdf)

[Lecture 2](/courses/quantum-mechanics/Sample_Lecture_Notes.pdf)

[Lecture 3](/courses/quantum-mechanics/Sample_Lecture_Notes.pdf)

#### Homework

[Homework 1](/courses/quantum-mechanics/Sample_Lecture_Notes.pdf)

[Homework 2](/courses/quantum-mechanics/Sample_Lecture_Notes.pdf)

[Homework 3](/courses/quantum-mechanics/Sample_Lecture_Notes.pdf)

#### Midterms

[Midterm 1](/courses/quantum-mechanics/Sample_Midterm.pdf)

[Midterm 2](/courses/quantum-mechanics/Sample_Midterm.pdf)

#### Exams

[Exam 1](/courses/quantum-mechanics/Sample_Exam.pdf)
