---
layout: page
title: "Stellar Structures"
---

#### Course Information

[Course Outline](/courses/stellar-structures/Sample_Course_Outline.pdf)

#### Lecture Notes

[Lecture 1](/courses/stellar-structures/Sample_Lecture_Notes.pdf)

[Lecture 2](/courses/stellar-structures/Sample_Lecture_Notes.pdf)

[Lecture 3](/courses/stellar-structures/Sample_Lecture_Notes.pdf)

#### Homework

[Homework 1](/courses/stellar-structures/Sample_Lecture_Notes.pdf)

[Homework 2](/courses/stellar-structures/Sample_Lecture_Notes.pdf)

[Homework 3](/courses/stellar-structures/Sample_Lecture_Notes.pdf)

#### Midterms

[Midterm 1](/courses/stellar-structures/Sample_Midterm.pdf)

[Midterm 2](/courses/stellar-structures/Sample_Midterm.pdf)

#### Exams

[Exam 1](/courses/stellar-structures/Sample_Exam.pdf)
